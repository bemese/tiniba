#!/bin/bash
P=$PWD
 make -f Makefile_two_bands_xeon clean; make -f  Makefile_two_bands_xeon 
