#!/bin/bash
P=$PWD
rsh quad01 "cd $P; make -f Makefile_two_bands_quad clean; make -f  Makefile_two_bands_quad" 
